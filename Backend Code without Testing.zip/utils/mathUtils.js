// mathUtils.js
function multiply(a, b) {
  return a * b;
}
module.exports = { multiply };
